function decryptText(xtext) {
  var key = "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz1029384756><#].@";
  var wTG;
  var mcH =  key.length / 2;
  var _newString = "";
  var dv;
  for (var x = 0; x < xtext.length; x++) {
    wTG = key.indexOf(xtext.charAt(x));
      if (wTG > mcH) {
        dv = wTG - mcH;
        _newString += key.charAt(33 - dv);
      } else {
      	if (key.indexOf(xtext.charAt(x)) < 0) {
          _newString += xtext.charAt(x);
        } else {
          dv = mcH - wTG;
          _newString += key.charAt(33 + dv);
        }
      }
    }
  return (_newString);
}